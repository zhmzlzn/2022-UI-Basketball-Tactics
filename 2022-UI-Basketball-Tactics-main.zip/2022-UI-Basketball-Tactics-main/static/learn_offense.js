function initialize(){
    $("#board").append("<img src='" + tactic["image"] + "' alt='" + tactic["title"] + " Image' class='w-100'></img>")
}

$(document).ready(function () {
    initialize()
});
